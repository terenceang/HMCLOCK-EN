set new-console on
